package com.ofbusiness.test.controller;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ofbusiness.test.entity.ChatLog;
import com.ofbusiness.test.model.BaseResponseModel;
import com.ofbusiness.test.model.ChatLogRequestModel;
import com.ofbusiness.test.model.ChatLogResponseModel;
import com.ofbusiness.test.service.ChatLogService;

@RestController
@RequestMapping("/chatlogs")
public class ChatLogController {
	
	@Autowired
	private ChatLogService chatLogService;
	
	
	@PostMapping("/{username}")
	public HttpEntity<Long> postChat(@PathVariable String username, @Valid @RequestBody ChatLogRequestModel requestModel){
		
		ChatLog chatLog = chatLogService.postChat(username, requestModel);
		return new ResponseEntity<Long>(chatLog.getMessageId(), HttpStatus.OK);
	}
	
	@GetMapping("/{username}")
	public HttpEntity<BaseResponseModel> postChat(@PathVariable String username, @RequestParam(name = "start" , required = true) int start, @RequestParam(name= "limit" , defaultValue = "10") int limit){
		
		Collection<ChatLogResponseModel> chatLogs = chatLogService.getChatLogs(username, start, limit);
		BaseResponseModel response = new BaseResponseModel();
		response.setData(chatLogs);
		response.setSize(chatLogs.size());
		return new ResponseEntity<BaseResponseModel>(response, HttpStatus.OK);
	}
	
	@DeleteMapping("/{username}")
	public HttpEntity<Void> deleteChats(@PathVariable String username){
		
		chatLogService.deleteChatLogs(username);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/{username}/{messageId}")
	public HttpEntity<Void> deleteChats(@PathVariable String username, @PathVariable Long messageId){
		
		chatLogService.deleteChatLog(username, messageId);
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}

}
