package com.ofbusiness.test.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ofbusiness.test.entity.ChatLog;

public interface ChatLogRepository extends JpaRepository<ChatLog, Long>{
	
	
	List<ChatLog> findAllByUsername(String username, Pageable pageable);
	
	void deleteAllByUsername(String username);
	
	void deleteAllByUsernameAndMessageId(String username, Long messageId);
	
	

}
