package com.ofbusiness.test.errorHanlder;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.ofbusiness.test.model.BaseResponseModel;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class ChatLogErrorHandler {
	
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public HttpEntity<BaseResponseModel> processHibernateValidator(MethodArgumentNotValidException e,
			WebRequest request) {

		BaseResponseModel res = new BaseResponseModel();

		String message = e.getBindingResult().getAllErrors().get(0).getDefaultMessage();
		log.error("Binding result is :" + message);
		res.setErrorMessage(message);
		return new ResponseEntity<BaseResponseModel>(res, HttpStatus.BAD_REQUEST);

	}
	
	@ResponseBody
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(Throwable.class)
	public HttpEntity<BaseResponseModel> processOtherException(Throwable e, WebRequest request) {

		log.error("fatal error :", e);
		BaseResponseModel res = new BaseResponseModel();

		res.setErrorMessage(e.getMessage());
		return new ResponseEntity<BaseResponseModel>(res, HttpStatus.INTERNAL_SERVER_ERROR);

	}

}
