package com.ofbusiness.test.service;

import java.util.Collection;

import com.ofbusiness.test.entity.ChatLog;
import com.ofbusiness.test.model.ChatLogRequestModel;
import com.ofbusiness.test.model.ChatLogResponseModel;

public interface ChatLogService {

	ChatLog postChat(String username, ChatLogRequestModel chatLog);

	Collection<ChatLogResponseModel> getChatLogs(String username, int start, int limit);

	void deleteChatLog(String username, Long messageId);

	void deleteChatLogs(String username);

}
