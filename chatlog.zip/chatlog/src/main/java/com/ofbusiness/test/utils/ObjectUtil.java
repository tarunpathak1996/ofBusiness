package com.ofbusiness.test.utils;

import org.springframework.beans.BeanUtils;

public class ObjectUtil {
	
	public static <T> T copyProperties(Class className, Object obj) {
		if(obj == null) {
			 return null;
		}
		T instance;
		try {
			instance = (T) className.newInstance();
			BeanUtils.copyProperties(obj, instance);
		}catch (Exception e) {
			throw new RuntimeException("Unable to copy object",e);
		}
		return instance;
	}

}
