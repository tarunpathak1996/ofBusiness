package com.ofbusiness.test.model;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class ChatLogResponseModel {
	
	Long messageId;
	String message;
	LocalDateTime timestamp;
	boolean isSent;

}
