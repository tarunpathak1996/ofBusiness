package com.ofbusiness.test.model;





import javax.validation.constraints.NotBlank;

import lombok.Data;

@Data
public class ChatLogRequestModel {
	
	@NotBlank(message = "chat message must not be blank")
	String message;
	
	
	boolean isSent;

}
