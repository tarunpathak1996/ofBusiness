package com.ofbusiness.test.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "CHAT_LOG")
@Getter
@Setter
public class ChatLog {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long messageId;
	
	@Column(length = 16, nullable = false)
	String username;
	
	@Column(nullable = false)
	String message;
	
	LocalDateTime timestamp = LocalDateTime.now();
	
	boolean isSent;

}
