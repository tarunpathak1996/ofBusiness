package com.ofbusiness.test.service;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.ofbusiness.test.entity.ChatLog;
import com.ofbusiness.test.model.ChatLogRequestModel;
import com.ofbusiness.test.model.ChatLogResponseModel;
import com.ofbusiness.test.repository.ChatLogRepository;
import com.ofbusiness.test.utils.ObjectUtil;

@Service
@Transactional
public class ChatLogServiceImpl implements ChatLogService {

	@Autowired
	private ChatLogRepository chatLogRepo;

	@Override
	public ChatLog postChat(String username, ChatLogRequestModel chatLogReqModel) {
		// TODO Auto-generated method stub
		ChatLog chatLogEntity = ObjectUtil.copyProperties(ChatLog.class, chatLogReqModel);
		chatLogEntity.setUsername(username);
		return chatLogRepo.save(chatLogEntity);
	}

	@Override
	public Collection<ChatLogResponseModel> getChatLogs(String username, int start, int limit) {
		Pageable sortedByTimestamp = PageRequest.of(start, limit, Sort.by("timestamp").descending());

		List<ChatLog> chatLogs = chatLogRepo.findAllByUsername(username, sortedByTimestamp);

		return chatLogs.stream()
				.map(chatLog -> (ChatLogResponseModel) ObjectUtil.copyProperties(ChatLogResponseModel.class, chatLog))
				.collect(Collectors.toList());

	}

	@Override
	public void deleteChatLog(String username, Long messageId) {
		chatLogRepo.deleteAllByUsernameAndMessageId(username, messageId);

	}

	@Override
	public void deleteChatLogs(String username) {
		
		chatLogRepo.deleteAllByUsername(username);


	}

}
