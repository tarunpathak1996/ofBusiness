package com.ofbusiness.test.repo;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.ofbusiness.test.entity.ChatLog;
import com.ofbusiness.test.repository.ChatLogRepository;

@DataJpaTest
public class ChatLogRepositoryTest {
	
	@Autowired
	private ChatLogRepository chatLogRepo;
	
	@Test
	public void testSaveChatMessage() {
		
		ChatLog chatLog = new ChatLog();
		chatLog.setMessage("dummy message");
		chatLog.setUsername("tarunpathak");
		chatLog.setSent(false);
		
		chatLogRepo.save(chatLog);
		
		Assertions.assertThat(chatLog.getMessageId()).isGreaterThan(0);
		
	}

}
