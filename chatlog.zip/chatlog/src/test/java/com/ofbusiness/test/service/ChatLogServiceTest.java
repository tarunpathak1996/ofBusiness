package com.ofbusiness.test.service;

import org.hamcrest.CoreMatchers;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;

import com.ofbusiness.test.entity.ChatLog;
import com.ofbusiness.test.repository.ChatLogRepository;

import mockit.Expectations;
import mockit.Injectable;
import mockit.Mocked;
import mockit.Tested;
import mockit.integration.junit4.JMockit;

@RunWith(JMockit.class)
public class ChatLogServiceTest {
   
   @Injectable
   private ChatLogRepository chatLogRepo;

   

   
}

